# Directly upload media from Google drive to Youtube using google colab
I <a href="https://github.com/agent87/"> agent87 </a>
as a deep learning enthusiast re-implemneting models using the google colab environment,
i aim to keep my operations/implementation on the internet as much as possible especially data heavy ones like video upload

Youtube uploader is python 2 script that will upload your machine learning output video especially computer vision from 
google colab to youtube using Youtube API V3

# NOTE:-
Only you are responsible for uploading copyrighted videos. \
( This tutorial is only for those,\
who are the owner of videos they are uploading,\
from any cloud drive to youtube )
# Pre-requisities (Full Guide)
Youtube Developer account/console:- \
<a href="https://console.developers.google.com"> Click-Here </a>

0. Error 403 access denied OAuth (Google Drive API & YouTube Data API error):- \
<a href="https://www.youtube.com/watch?v=-XywEY2PGIY"> Video Guide </a>

1. Create & Download Credentials.json file in Google Cloud Platform:- \
<a href="https://www.youtube.com/watch?v=6MBLrH1j6Tg"> Video Guide </a>

2. Enable YouTube Data API v3 in Google Cloud Platform:- \
<a href="https://www.youtube.com/watch?v=fN8WwVQTWYk"> Video Guide </a>

3. Upload videos from Google Drive, Shared Drive, OneDrive, Mega, DropBox to YOUTUBE:- \
<a href="https://www.youtube.com/watch?v=8NuUkvGM_ko"> Video Guide </a>

# Dependencies
The script shall automatically install all the dependencies 

# Open Google Colab:-
<a href="https://colab.research.google.com/"> Google Colab </a> 

# Download & upload this notebook in colab (Cloud Drive to YouTube uploader):-
<a href="http://upload-4ever.com/d/MdRp"> Link 1 </a> \
OR \
<a href="https://shrinke.me/6G7x1etb"> Link 2 </a> 


# Credits:-
<a href="https://github.com/agent87/"> agent87 </a> \
<a href="https://github.com/BoostUpStation/youtube-up"> boostupstation </a> - extra functionality.
