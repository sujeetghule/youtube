import os
os.system('sudo apt-get install python2.7')  #sudo...just incase a fella runs it on desktop environmet with permmision involved.
os.system('sudo apt-get install python-pip')
os.system('pip2 install --upgrade google-api-python-client')
os.system('pip2 install --upgrade google-auth-oauthlib google-auth-httplib2')

